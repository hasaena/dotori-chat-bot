"""DuckDuckGo Search API toolkit."""
